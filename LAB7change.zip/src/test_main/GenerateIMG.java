package test_main;

public class GenerateIMG {

    public void generateGraphToPath(DWGraph graph) {
        graph.showIMG();
    }

}

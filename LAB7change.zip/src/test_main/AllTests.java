package test_main;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ testcase1.class, testcase2.class, testcase3.class, testcase4.class, testcase5.class, testcase6.class,
		testcase7.class })
public class AllTests {

}
